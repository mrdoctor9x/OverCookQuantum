﻿using UnityEngine;

namespace Quantum.Demo {
  public class UIRoomPlayer : MonoBehaviour {
    public UnityEngine.UI.Text Name;
  }
}