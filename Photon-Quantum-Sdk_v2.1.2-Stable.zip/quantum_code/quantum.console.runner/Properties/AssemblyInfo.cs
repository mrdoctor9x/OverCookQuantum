﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("quantum.console.runner")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("quantum.console.runner")]
[assembly: AssemblyCopyright("Copyright © Exit Games 2020")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("b2c620e4-13f8-4ecd-a7f0-88724216e90c")]
[assembly: AssemblyVersion("2.1.2.0")]
[assembly: AssemblyFileVersion("2.1.2.0")]
[assembly: AssemblyInformationalVersion("2.1.2 Stable 1129 2.1/develop (35743e068)")]
