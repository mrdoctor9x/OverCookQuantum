﻿using UnityEngine;
using UnityEngine.UI;

public class QuantumMultiClientPlayerView : MonoBehaviour {
  public Text Label;
  public Toggle Input;
  public Toggle View;
  public Toggle Gizmos;
  public Button Quit;
}
