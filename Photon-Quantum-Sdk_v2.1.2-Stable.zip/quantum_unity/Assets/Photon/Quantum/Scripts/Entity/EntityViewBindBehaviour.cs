﻿public enum EntityViewBindBehaviour {
  NonVerified,
  Verified
}