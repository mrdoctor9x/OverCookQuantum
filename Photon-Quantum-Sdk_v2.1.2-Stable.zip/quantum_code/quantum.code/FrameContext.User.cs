namespace Quantum {
  public partial class FrameContextUser {
    
  }
}